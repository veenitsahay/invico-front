import React, { useState } from "react";
import axios from "axios";
import { GoogleLogin, googleLogout } from "@react-oauth/google";
import { useNavigate } from "react-router-dom";

const LoginPage: React.FC = () => {
  const [username, setUsername] = useState<string>("");
  const [password, setPassword] = useState<string>("");
  const navigate = useNavigate();

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    axios
      .post("http://127.0.0.1:8000/api/token/", { username, password })
      .then((response) => {
        console.log("Login success:", response.data);
        navigate("/matrix");
      })
      .catch((error) => {
        console.error("Login error:", error.message);
      });
  };

  const handleGoogleSuccess = (credentialResponse: any) => {
    console.log("Google login success", credentialResponse);
    navigate("/matrix");
  };

  const handleGoogleError = () => {
    console.error("Google login failed");
  };

  const handleFacebookResponse = (response: any) => {
    console.log("Facebook login success", response);
    navigate("/matrix");
  };

  return (
    <div style={{ padding: "2rem", textAlign: "center" }}>
      <h2>Login Page</h2>
      <input
        type="text"
        value={username}
        placeholder="Username"
        onChange={(e) => setUsername(e.target.value)}
      />
      <br />
      <input
        type="password"
        value={password}
        placeholder="Password"
        onChange={(e) => setPassword(e.target.value)}
      />
      <br />
      <button type="submit" onClick={handleLogin}>
        Submit
      </button>

      <div style={{ marginTop: "2rem" }}>
        <h4>Or login with</h4>
        <GoogleLogin onSuccess={handleGoogleSuccess} onError={handleGoogleError} />
        <br />
      </div>
    </div>
  );
};

export default LoginPage;
