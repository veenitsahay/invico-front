import React from 'react';

const Box5: React.FC = () => {
  return <div>Content of Box 5</div>;
};

export default Box5;
