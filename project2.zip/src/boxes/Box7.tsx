// src/components/Box7.tsx
import React from 'react';

const Box7: React.FC = () => {
  return <div>Content of Box 7</div>;
};

export default Box7;
