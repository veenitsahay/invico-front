import React from 'react';

const Box6: React.FC = () => {
  return <div>Content of Box 6</div>;
};

export default Box6;
