// src/components/Box8.tsx
import React from 'react';

const Box8: React.FC = () => {
  return <div>Content of Box 8</div>;
};

export default Box8;
