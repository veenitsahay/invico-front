// src/components/Box4.tsx
import React from 'react';

const Box4: React.FC = () => {
  return <div>Content of Box 4</div>;
};

export default Box4;
